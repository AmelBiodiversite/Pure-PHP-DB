<?php
define('APP_CURRENCY', '€');
define('APP_CURRENCY_POS', 'right');
